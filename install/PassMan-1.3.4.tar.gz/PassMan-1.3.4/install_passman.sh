#!/usr/bin/env bash
# Author: Adam Coffee
# Licensed under the three-clause BSD license, found in the LICENSE file.

# Install packages
echo "Several packages may have to be installed to compile and install PassMan."
echo "Do you want to install them now? [y/n]"
read answer

if [ "$answer" = "y" ] ; then
    sudo apt-get update && sudo apt-get install xdotool libcrypto++* yubikey-personalization build-essential qt5-default
else 
    echo "Quitting PassMan installation."
    exit
fi

# Compile program
echo "Do you want to compile the program now? [y/n]"
read answer

if [ "$answer" = "y" ] ; then
    cd PassMan
    qmake PassMan.pro
    make
else
    echo "Quitting PassMan installation."
    exit
fi

# Install program
if [ -f PassMan ] ; then
    echo "The program successfully compiled."
    echo "Do you want to install it now? [y/n]"
    read answer

    if [ "$answer" = "y" ] ; then
        echo "Installing binary."
        sudo install PassMan /usr/bin
        echo "Installing icon."
        sudo mkdir /usr/share/PassMan
        sudo mkdir /usr/share/PassMan/icons
        sudo cp PassMan.png /usr/share/PassMan/icons/PassMan.png
        echo "Installing shortcut."
        sudo desktop-file-install passman.desktop
    fi

    echo "PassMan installation finished."
    echo "To run, type PassMan from a terminal, or select it from your system menu."
else
    echo "The program failed to compile."
    echo "Quitting PassMan installation."
    exit
fi
