#!/usr/bin/env bash
# Author: Adam Coffee
# Licensed under the three-clause BSD license, found in the LICENSE file.

# Uninstall files
echo "Do you want to uninstall PassMan now? [y/n]"
read answer

if [ "$answer" = "y" ] ; then
    echo "Uninstalling binary and icon."
    sudo rm /usr/bin/PassMan
    sudo rm /usr/share/PassMan -r
else 
    echo "Quitting PassMan uninstallation."
    exit
fi
